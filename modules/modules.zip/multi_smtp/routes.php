<?php
declare(strict_types=1);

if (str_starts_with($routePath, '/multi-smtp')) {
    $db = Database::getConnection();
    
    $action = $_GET['action'] ?? '';
    
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        if (!Auth::checkCsrf()) {
            $_SESSION['flash_error'] = 'CSRF validation failed.';
            header('Location: ' . getSetting('app_url') . '/multi-smtp');
            exit;
        }
        if ($action === 'add') {
            $name = trim($_POST['name'] ?? 'New Server');
            $host = trim($_POST['host'] ?? '');
            $port = (int)($_POST['port'] ?? 587);
            $username = trim($_POST['username'] ?? '');
            $password = trim($_POST['password'] ?? '');
            $encryption = trim($_POST['encryption'] ?? 'tls');
            $fromEmail = trim($_POST['from_email'] ?? '');
            $fromName = trim($_POST['from_name'] ?? '');
            $dailyLimit = (int)($_POST['daily_limit'] ?? 0);
            
            $st = $db->prepare("INSERT INTO smtp_servers (name, host, port, username, password, encryption, from_email, from_name, daily_limit) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
            $st->execute([$name, $host, $port, $username, $password, $encryption, $fromEmail, $fromName, $dailyLimit]);
            
            $_SESSION['flash_success'] = 'SMTP Server added successfully.';
            header('Location: ' . getSetting('app_url') . '/multi-smtp');
            exit;
        } elseif ($action === 'delete') {
            $id = (int)($_POST['id'] ?? 0);
            $db->prepare("DELETE FROM smtp_servers WHERE id = ?")->execute([$id]);
            $_SESSION['flash_success'] = 'SMTP Server removed.';
            header('Location: ' . getSetting('app_url') . '/multi-smtp');
            exit;
        } elseif ($action === 'toggle') {
            $id = (int)($_POST['id'] ?? 0);
            $db->prepare("UPDATE smtp_servers SET status = 1 - status WHERE id = ?")->execute([$id]);
            $_SESSION['flash_success'] = 'SMTP Server status toggled.';
            header('Location: ' . getSetting('app_url') . '/multi-smtp');
            exit;
        } elseif ($action === 'reset_errors') {
            $id = (int)($_POST['id'] ?? 0);
            $db->prepare("UPDATE smtp_servers SET error_count = 0 WHERE id = ?")->execute([$id]);
            $_SESSION['flash_success'] = 'Error count reset.';
            header('Location: ' . getSetting('app_url') . '/multi-smtp');
            exit;
        }
    }
    
    $servers = $db->query("SELECT * FROM smtp_servers ORDER BY created_at DESC")->fetchAll();
    
    $title = 'Multi-SMTP Intelligent Routing Engine';
    $viewPath = __DIR__ . '/view.php';
    include dirname(dirname(__DIR__)) . '/views/layout.php';
    exit;
}

// Route: /multi-smtp/test (Test Server Connection API)
if ($routePath === '/multi-smtp/test') {
    header('Content-Type: application/json');
    if (!Auth::check()) {
        echo json_encode(['success' => false, 'error' => 'Unauthorized']);
        exit;
    }

    $db = Database::getConnection();
    $serverId = (int)($_GET['id'] ?? 0);
    $st = $db->prepare("SELECT * FROM smtp_servers WHERE id = ?");
    $st->execute([$serverId]);
    $server = $st->fetch();

    if (!$server) {
        echo json_encode(['success' => false, 'error' => 'SMTP Server record not found']);
        exit;
    }

    require_once dirname(dirname(__DIR__)) . '/core/Mailer.php';
    $mailer = new Mailer();
    
    $recipient = $_SESSION['user_email'] ?? getSetting('smtp_from_email') ?: 'test@localhost';
    $res = $mailer->sendCustom(
        $server['host'],
        (int)$server['port'],
        $server['username'],
        $server['password'],
        $server['encryption'],
        $server['from_email'] ?: getSetting('smtp_from_email'),
        $server['from_name'] ?: getSetting('smtp_from_name', 'Merlin Test'),
        $recipient,
        'Multi-SMTP Connection Test (' . $server['name'] . ')',
        '<p>This is a test email from Multi-SMTP server: <strong>' . htmlspecialchars($server['name']) . '</strong></p>'
    );

    echo json_encode($res);
    exit;
}
